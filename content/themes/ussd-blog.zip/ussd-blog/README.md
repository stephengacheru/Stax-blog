# simple-ghost-theme
A simple and clean theme for Ghost
